angular.module('AngularStore').config(function ($routeProvider) {
    $routeProvider
        .when('/store', {
            templateUrl: "templates/store.html",
            controller: "storeController"
        })

        .when('/cart', {
            templateUrl: "templates/shoppingCart.html",
            controller: "storeController"
        })

        .when('/products/:productSku', {
            templateUrl: "templates/product.html",
            controller: "storeController"
        })

        .otherwise({
            redirectTo: '/store'
        });
});