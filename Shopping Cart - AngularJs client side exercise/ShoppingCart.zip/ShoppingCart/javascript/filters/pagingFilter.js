angular.module('AngularStore').filter('pagingFilter', function () {
    return function (callection, currentPage, numPerPage) {

        if (Number.isInteger(currentPage) && Number.isInteger(numPerPage)) {
            return callection.slice((currentPage-1)*numPerPage,currentPage*numPerPage);
        }
        else {
            return callection
        }
    }
});

